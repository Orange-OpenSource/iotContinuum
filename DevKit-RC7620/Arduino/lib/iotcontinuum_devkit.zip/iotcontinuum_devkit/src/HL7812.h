#ifndef HL7812_H
#define HL7812_H

#include "HL7812/HL7812Client.h"

#endif
